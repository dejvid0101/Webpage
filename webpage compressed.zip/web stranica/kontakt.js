
$(function(){
$("#fefe").dialog({

    autoOpen: false,
    modal: true,
    
buttons:{
    
    "Odustani":function(){$("#fefe").dialog("close");}
}


    }


)
})
console.log(76);
function zaza(){
console.log(32);
$("#fefe").dialog("open");


};

console.log(9)
