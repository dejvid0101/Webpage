
const url="http://www.fulek.com/VUA/SUPIT/GetNastavniPlan";
const url2="http://www.fulek.com/VUA/supit/GetKolegij/5";

const xhr =new XMLHttpRequest();
xhr.open("get",url);

xhr.onreadystatechange=function(){
    if(xhr.readyState===XMLHttpRequest.DONE&&xhr.status===200){
        console.log(xhr.response)
    }
}


fetch(url).then(function(response){
    response.json().then(function(fefe){
        
        var vrijednosti=fefe;
        
        var naziv=[];
        //var polje=document.getElementById("input");
        
        for (var i = 0; i < vrijednosti.length; i++) {
               
naziv.push(vrijednosti[i].label);
                
               
             }
            console.log(naziv[0]);
            $( "#input" ).autocomplete({
                source: naziv,
                select: function(event, ui){
                    var urlnovi;
                    var wert=ui.item.label
                    for(var i = 0; i < vrijednosti.length; i++){
                        if(wert===vrijednosti[i].label){
                            var id=vrijednosti[i].value;
                            urlnovi="http://www.fulek.com/VUA/supit/GetKolegij/"+id;
                        }
                    
                }
                glavna(urlnovi);}
              });
        })
            })


    
//xhr.send();
//console.log(vrijednosti[5].kolegij)



//window.onload=function(){
var k=0;
function uvec(k) {
    k++;
    return k;
}

var ectsUkupno=0;
function ukupnoEcts(ectsUkupno1,d){
ectsUkupno1=ectsUkupno1+d;
return ectsUkupno1;
}

function smanjiEcts(ectsUkupno1,d){
    ectsUkupno1=ectsUkupno1-d; 
return ectsUkupno1;
}

var satiUkupno=0;
function ukupnoSati(satiUkupno1,d){
satiUkupno1=satiUkupno1+d;
return satiUkupno1;
}

function smanjiSate(satiUkupno1,d){
    satiUkupno1=satiUkupno1-d; 
return satiUkupno1;
}


function glavna(url2){



fetch(url2).then(function(response){
    response.json().then(function(fefe){var podaci=fefe;
        var t=uvec(k);
        k=uvec(k);
        var str=podaci.kolegij;
        var tbodyRef = document.getElementById('tabla').getElementsByTagName('tbody')[0];

var newRow = tbodyRef.insertRow();

var newCell = newRow.insertCell();

var newText = document.createTextNode(str);
newCell.appendChild(newText);

str=podaci.ects;

newCell=newRow.insertCell();
newText=document.createTextNode(str);
newCell.appendChild(newText);

str=podaci.sati;

newCell=newRow.insertCell();
newText=document.createTextNode(str);
newCell.appendChild(newText);

str=podaci.predavanja;

newCell=newRow.insertCell();
newText=document.createTextNode(str);
newCell.appendChild(newText);

str=podaci.vjezbe;

newCell=newRow.insertCell();
newText=document.createTextNode(str);
newCell.appendChild(newText);

str=podaci.tip;

newCell=newRow.insertCell();
newText=document.createTextNode(str);
newCell.appendChild(newText);

str="Obriši";
var tag = document.createElement("button");
var l=document.createTextNode(str);
tag.appendChild(l);
    newCell=newRow.insertCell();
newText=document.createTextNode(str);
newCell.appendChild(tag);

tag.onclick=function fefe(){var s=$(tag).parents()[3];

$(tag).closest('tr').remove();
ectsUkupno=smanjiEcts(ectsUkupno,d);
satiUkupno=smanjiSate(satiUkupno,f);
var u=document.getElementById("uEcts");
var v=document.getElementById("uSati");
u.innerHTML=ectsUkupno;
v.innerHTML=satiUkupno;
}

str=podaci.ects;
    var d=str;

    
    
ectsUkupno=ukupnoEcts(ectsUkupno,d);
str=podaci.sati;
    var f=str;
satiUkupno=ukupnoSati(satiUkupno,f);
var u=document.getElementById("uEcts");
var v=document.getElementById("uSati");
u.innerHTML=ectsUkupno;
v.innerHTML=satiUkupno;
    return fefe;
    


    

    })})
}

   

